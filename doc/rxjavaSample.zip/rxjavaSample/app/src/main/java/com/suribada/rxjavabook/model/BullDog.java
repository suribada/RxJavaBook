package com.suribada.rxjavabook.model;

public class BullDog extends Dog{
    BullDog(String name) {
        super(name);
    }
}
