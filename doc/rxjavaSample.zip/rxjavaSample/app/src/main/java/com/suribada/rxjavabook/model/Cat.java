package com.suribada.rxjavabook.model;

public class Cat extends Animal {
}
