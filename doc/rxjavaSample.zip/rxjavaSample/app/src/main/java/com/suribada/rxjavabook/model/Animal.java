package com.suribada.rxjavabook.model;

public class Animal {
}
