package com.suribada.rxjavabook.chap1;

/**
 * Created by lia on 2018-02-05.
 */

public class Bookmark {

    String userId;

    public String getUserId() {
        return userId;
    }

}
