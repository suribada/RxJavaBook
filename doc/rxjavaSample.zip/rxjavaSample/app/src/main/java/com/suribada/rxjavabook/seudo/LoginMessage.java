package com.suribada.rxjavabook.seudo;

/**
 * Created by lia on 2017-10-14.
 */

public class LoginMessage {

    public static final String LOGIN_FINISH = "LOGIN_FINISH";
    public static final String LOGOUT_FINISH = "LOGOUT_FINISH";
}
