package com.suribada.rxjavabook.seudo;

/**
 * Created by lia on 2018-01-21.
 */

class Schedule {

    String date;
}
