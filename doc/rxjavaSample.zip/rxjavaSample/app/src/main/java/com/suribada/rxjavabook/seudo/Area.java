package com.suribada.rxjavabook.seudo;

/**
 * Created by Naver on 2017. 10. 12..
 */
public class Area {

    public String code;
}
