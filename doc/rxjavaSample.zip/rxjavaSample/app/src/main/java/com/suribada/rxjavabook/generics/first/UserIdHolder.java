package com.suribada.rxjavabook.generics.first;

import com.suribada.rxjavabook.generics.second.Holder;

/**
 * Created by Noh.Jaechun on 2018. 12. 22..
 */
public class UserIdHolder extends Holder<String> {
}
