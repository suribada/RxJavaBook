package com.suribada.rxjavabook.generics.second;

/**
 * Created by Noh.Jaechun on 2018. 12. 21..
 */
public interface Image {

    void makeThumbnail();

    void share();

}
