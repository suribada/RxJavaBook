package com.suribada.rxjavabook.generics.first;

/**
 * Created by Noh.Jaechun on 2018. 12. 21..
 */
public class CommentImage {

    public void makeThumbnail() {
    }

    public void share() {
    }

}
