package com.suribada.rxjavabook.seudo;

public class Movie {
    public String title;
    public String link;
    public String image;
    public String subtitle;
    public String pubDate;
    public String director;
    public String actor;
    public float userRating;
}