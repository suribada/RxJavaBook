package com.suribada.rxjavabook.generics.first;

/**
 * Created by Noh.Jaechun on 2018. 12. 21..
 */
class ArticleImage {
    public void makeThumbnail() {
    }

    public void share() {
    }
}
